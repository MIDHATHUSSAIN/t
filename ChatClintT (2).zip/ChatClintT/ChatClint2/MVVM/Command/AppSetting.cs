﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ChatClint2.MVVM.Command
{
    class AppSetting : INotifyPropertyChanged
    {
        private static AppSetting _instance;

        private static readonly object _lock = new object();
        private AppSetting()
        {

        }

        public static AppSetting Instance()
        {
            if (_instance == null)
            {
                lock (_lock)
                {
                    if (_instance == null)
                    {
                        _instance = new AppSetting();
                    }
                }
            }
            return _instance;
        }

        private ObservableCollection<string> myUL;

        public event PropertyChangedEventHandler? PropertyChanged;

        public ObservableCollection<string> MYUL
        {
            get { return myUL; }

            set { 
                myUL = (ObservableCollection<string>)value;
                OnPropertyChanged();
            }

        }
        private void OnPropertyChanged([CallerMemberName] string PropertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(PropertyName));
        }

    }
}
