﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using ChatClint2.MVVM.Command;

namespace ChatClint2.Net
{
    class Server
    {
        private volatile bool _isConnected = false;


        TcpClient _client;
        private NetworkStream stream;
        public NetworkStream Stream => stream;
        public Server()
        {
            _client = new TcpClient();
            StartReconnectLoop();
        }

        public string ConnectToServer(string userName)
        {
            try
            {
                if (!_client.Connected)
                {
                    _client.Connect("127.0.0.1", 5001);
                }
                stream = _client.GetStream();

                if (string.IsNullOrEmpty(userName))
                {
                    return "please enteryouser Name";
                }

                byte[] buf = Encoding.UTF8.GetBytes(userName);
                stream.Write(buf, 0, buf.Length);

                byte[] userLit = new byte[1024];

                int lrb = stream.Read(userLit, 0, userLit.Length);

                return Encoding.UTF8.GetString(userLit, 0, lrb);

            }
            catch (Exception ex)
            {

                return "Server is not connected";
            }

        }

        private async Task dd()
        {
            try
            {
                _client?.Close();
                _client = new TcpClient();

                await _client.ConnectAsync("127.0.0.1", 5001);
                stream = _client.GetStream();

                _isConnected = true;
                Console.WriteLine("Reconnected");
               
            }
            catch
            {
                _isConnected = false;
            }
        }


        public void StartReconnectLoop()
        {
            Task.Run(async () =>
            {
                while (true)
                {
                    if (!_isConnected)
                    {
                        await dd();
                    }

                    await Task.Delay(10_000);
                }
            });
        }


        public bool SendMessage(string message, string targetUser)
        {
            try
            {
                if (string.IsNullOrEmpty(message) || string.IsNullOrEmpty(targetUser))
                {
                    return false;
                }
                else
                {
                    string packet = $"TO:{targetUser}|MSG:{message}";
                    byte[] data = Encoding.UTF8.GetBytes(packet);
                    stream.Write(data, 0, data.Length);

                    return true;
                }

            }
            catch (Exception ex)
            {
                return false;
            }
        }



    }
}
