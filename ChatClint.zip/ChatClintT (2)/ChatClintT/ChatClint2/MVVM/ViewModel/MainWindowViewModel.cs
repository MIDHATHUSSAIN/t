﻿using ChatClint2.MVVM.Command;
using ChatClint2.Net;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;


using System.Windows.Input;

namespace ChatClint2.MVVM.ViewModel
{
    class MainWindowViewModel : INotifyPropertyChanged
    {
        private Server _server;
        private string _userName;
        private string _message = "";
        private string _chatLog;
        private string _selectedUser;
        private bool _isConnecting = false;

        public ICommand ConnectBtn { get; }
        public ICommand SendCommand { get; }

        public string Message
        {
            get => _message;
            set { _message = value; OnPropertyChanged(); (SendCommand as RelayCommand)?.RaiseCanExecuteChanged(); }
        }

        public string ChatLog
        {
            get => _chatLog;
            set { _chatLog = value; OnPropertyChanged(); }
        }

        public string UserName
        {
            get => _userName;
            set { _userName = value; OnPropertyChanged(); (ConnectBtn as RelayCommand)?.RaiseCanExecuteChanged(); }
        }

        public string SelectedUser
        {
            get => _selectedUser;
            set { _selectedUser = value; OnPropertyChanged(); }
        }

       
        public AppSetting Settings => AppSetting.Instance();

        public MainWindowViewModel()
        {
            _server = new Server();
            ConnectBtn = new RelayCommand(async () => await HandleConnect(), () => !string.IsNullOrEmpty(UserName) && !_isConnecting);
            SendCommand = new RelayCommand(() => SendMessage(), () => !string.IsNullOrEmpty(Message) && _server.IsConnected);          
            StartListening();
        }

        private async Task HandleConnect()
        {
            _isConnecting = true;
            string result = await _server.ConnectToServerAsync(UserName);

            if (result != "Server is not connected")
            {
                UpdateUserList(result);
                ChatLog += "System: Connected to server.\n";
                (SendCommand as RelayCommand)?.RaiseCanExecuteChanged();
            }
            else
            {
                MessageBox.Show("Could not connect to server.");
            }
            _isConnecting = false;
        }

        private void StartListening()
        {
            Task.Run(async () =>
            {
                byte[] buffer = new byte[2048];
                while (true)
                {
                    try
                    {
                        if (_server.IsConnected && _server.Stream != null)
                        {
                            int bytesRead = await _server.Stream.ReadAsync(buffer, 0, buffer.Length);
                            if (bytesRead == 0) throw new Exception("Lost connection");

                            string data = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                            Application.Current.Dispatcher.Invoke(() =>
                            {
                                if (data.StartsWith("CLIENTS:"))
                                {
                                    UpdateUserList(data);
                                }
                                else
                                {
                                    ChatLog += $"{data}\n";
                                }
                            });
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(UserName) && !_isConnecting)
                            {
                                await Application.Current.Dispatcher.InvokeAsync(async () => {
                                    await HandleConnect();
                                });
                            }
                            await Task.Delay(2000);
                        }
                    }
                    catch
                    {
                        // Connection dropped
                        Application.Current.Dispatcher.Invoke(() => ChatLog += "System: Connection lost. Trying to reconnect...\n");
                        await Task.Delay(3000);
                    }
                }
            });
        }

        private void UpdateUserList(string rawData)
        {
            //Settings.MYUL = new ObservableCollection<string>(users);
            string data = rawData.Replace("CLIENTS:", "");
            Settings.MYUL = new ObservableCollection<string>(data.Split(',').Select(u => u.Trim()));
        }

        private void SendMessage()
        {
            bool success = _server.SendMessage(Message, SelectedUser);
            if (success)
            {
                ChatLog += $"You -> {SelectedUser}: {Message}\n";
                Message = "";
            }
            else
            {
                //MessageBox.Show("Message failed to send. Check connection.");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }





        //string UL;
        //bool isuserConnected = true;
        //bool isError = true;
        //public ICommand ConnectBtn { get; }
        //private string _userName;

        //private string message = "Message";
        //private string chatLog;


        //public AppSetting Settings
        //{
        //    get { return AppSetting.Instance(); }
        //}

        //public string Message
        //{
        //    get => message;
        //    set
        //    {
        //        message = value;
        //        OnPropertyChanged(nameof(Message));
        //    }
        //}

        //public string ChatLog
        //{
        //    get => chatLog;
        //    set
        //    {
        //        chatLog = value;
        //        OnPropertyChanged(nameof(ChatLog));
        //    }
        //}

        //public ICommand SendCommand { get; }
        //public string UserName
        //{
        //    get { return _userName; }
        //    set
        //    {
        //        _userName = value;
        //        OnPropertyChanged();
        //        ;
        //        (ConnectBtn as RelayCommand)?.RaiseCanExecuteChanged();
        //    }
        //}

        //private Server _server;

        //public event PropertyChangedEventHandler? PropertyChanged;

        //public MainWindowViewModel()
        //{
        //    _server = new Server();

        //    ConnectBtn = new RelayCommand(() => UserList(), () => !string.IsNullOrEmpty(UserName));
        //    SendCommand = new RelayCommand(() => SendMessage(), () => !string.IsNullOrEmpty(message));
        //    //ConnectBtn = new RelayCommand(() => _server.ConnectToServer(UserName), () => !string.IsNullOrEmpty(UserName));

        //}
        //protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        //{
        //    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        //}


        //private void UserList()
        //{
        //    if (isuserConnected)
        //    {
        //        UL = _server.ConnectToServer(UserName);
        //        StartListening();
        //        Console.Write(UL);
        //        string data = UL.Replace("CLIENTS:", "");

        //        Settings.MYUL = new ObservableCollection<string>(data.Split(',').Select(u => u.Trim()));


        //        if (UL != "Server is not connected")
        //        {
        //            isuserConnected = false;

        //        }

        //    }

        //}

        //private void StartListening()
        //{
        //    Task.Run(() =>
        //    {
        //        byte[] buffer = new byte[1024];
        //        while (true)
        //        {
        //            try
        //            {
        //                int bytesRead = _server.Stream.Read(buffer, 0, buffer.Length);
        //                if (bytesRead == 0)
        //                {
        //                    isuserConnected = true;
        //                    break;
        //                }


        //                string data = Encoding.UTF8.GetString(buffer, 0, bytesRead);

        //                Application.Current.Dispatcher.Invoke(() =>
        //                {
        //                    if (data.StartsWith("CLIENTS:"))
        //                    {
        //                        string users = data.Replace("CLIENTS:", "");
        //                        Settings.MYUL = new ObservableCollection<string>(
        //                            users.Split(',').Select(u => u.Trim())
        //                        );
        //                    }
        //                    else
        //                    {
        //                        ChatLog += $"Server: {data}\n";
        //                    }
        //                });
        //            }
        //            catch
        //            {
        //                isuserConnected = true;   
        //                break;
        //            }
        //        }
        //    });
        //}


        //private string _selectedUser;
        //public string SelectedUser
        //{
        //    get => _selectedUser;
        //    set
        //    {
        //        _selectedUser = value;
        //        OnPropertyChanged();

        //        isError = _server.SendMessage(Message, _selectedUser);
        //        checkingforerror(isError);

        //        //_server.WantToConnect(_selectedUser);
        //    }
        //}

        //private void SendMessage()
        //{

        //    //string reply = _server.SendMessage(Message, _selectedUser);

        //    isError = _server.SendMessage(Message, _selectedUser);
        //    checkingforerror(isError);
        //    if (isError)
        //    {
        //        ChatLog += $"You: {Message}\n";
        //    }

        //    //ChatLog += $"Server: {reply}\n";

        //    Message = "";
        //}

        //private void checkingforerror(bool isError)
        //{
        //    if (!isError)
        //    {
        //        MessageBox.Show("server is turend off");
        //    }


        //}
    }
}
