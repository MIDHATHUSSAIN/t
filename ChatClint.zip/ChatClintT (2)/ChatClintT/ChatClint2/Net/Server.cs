﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using ChatClint2.MVVM.Command;

namespace ChatClint2.Net
{
    class Server
    {
        private TcpClient _client;
        private NetworkStream _stream;
        public NetworkStream Stream => _stream;

        private volatile bool _isConnected = false;
        public bool IsConnected => _client != null && _client.Connected;

        public Server()
        {
        
        }

        public async Task<string> ConnectToServerAsync(string userName)
        {
            try
            {
                
                _client?.Close();
                _client = new TcpClient();

                await _client.ConnectAsync("127.0.0.1", 5001);
                _stream = _client.GetStream();

                if (string.IsNullOrEmpty(userName)) return "Please enter Username";

                byte[] buf = Encoding.UTF8.GetBytes(userName);
                await _stream.WriteAsync(buf, 0, buf.Length);
                byte[] userLit = new byte[1024];
                int lrb = await _stream.ReadAsync(userLit, 0, userLit.Length);

                _isConnected = true;
                return Encoding.UTF8.GetString(userLit, 0, lrb);
            }
            catch (Exception)
            {
                _isConnected = false;
                return "Server is not connected";
            }
        }

        public bool SendMessage(string message, string targetUser)
        {
            try
            {
                if (!IsConnected || _stream == null) return false;

                string packet = $"TO:{targetUser}|MSG:{message}";
                byte[] data = Encoding.UTF8.GetBytes(packet);
                _stream.Write(data, 0, data.Length);
                return true;
            }
            catch
            {
                _isConnected = false;
                return false;
            }
        }






        //private volatile bool _isConnected = false;


        //TcpClient _client;
        //private NetworkStream stream;
        //public NetworkStream Stream => stream;
        //public Server()
        //{
        //    _client = new TcpClient();
        //    StartReconnectLoop();
        //}

        //public string ConnectToServer(string userName)
        //{
        //    try
        //    {
        //        if (!_isConnected)
        //        {
        //            _client.Connect("127.0.0.1", 5001);
        //        }
        //        stream = _client.GetStream();

        //        if (string.IsNullOrEmpty(userName))
        //        {
        //            return "please enteryouser Name";
        //        }
        //        _isConnected = true;
        //        byte[] buf = Encoding.UTF8.GetBytes(userName);
        //        stream.Write(buf, 0, buf.Length);

        //        byte[] userLit = new byte[1024];

        //        int lrb = stream.Read(userLit, 0, userLit.Length);

        //        return Encoding.UTF8.GetString(userLit, 0, lrb);

        //    }
        //    catch (Exception ex)
        //    {
        //        _isConnected = false;
        //        return "Server is not connected";
        //    }

        //}


        //private async Task TryReconnect()
        //{
        //    try
        //    {
        //        if (_client.Connected)
        //            return;

        //        _client.Close();
        //        _client = new TcpClient();

        //        await _client.ConnectAsync("127.0.0.1", 5001);

        //        stream = _client.GetStream();
        //        _isConnected = true;

        //        Console.WriteLine("Reconnected to server");
        //    }
        //    catch
        //    {
        //        _isConnected = false;
        //    }
        //}


        //public void StartReconnectLoop()
        //{
        //    Task.Run(async () =>
        //    {
        //        while (true)
        //        {
        //            if (!_isConnected)
        //            {
        //                await TryReconnect();
        //            }

        //            await Task.Delay(10000);
        //        }
        //    });
        //}

        //public bool SendMessage(string message, string targetUser)
        //{
        //    try
        //    {
        //        if (string.IsNullOrEmpty(message) || string.IsNullOrEmpty(targetUser))
        //        {
        //            return false;
        //        }
        //        else
        //        {
        //            string packet = $"TO:{targetUser}|MSG:{message}";
        //            byte[] data = Encoding.UTF8.GetBytes(packet);
        //            stream.Write(data, 0, data.Length);

        //            return true;
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        return false;
        //    }
        //}



    }
}
