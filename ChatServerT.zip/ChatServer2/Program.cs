﻿using System.Net;
using System.Net.Sockets;
using System.Text;

class Programm
{
    static Dictionary<string, TcpClient> clients = new();

    static HashSet<string> knownUsers = new();
    static object lockObj = new object();
   static string patth; 
    static void Main()
    {
        
        try
        {
            //patth = "C:\\Users\\mhussain\\source\\repos\\ChatServer2\\users.txt";
            int port = 5001;

            TcpListener server = new TcpListener(IPAddress.Any, port);

            server.Start();

            Console.WriteLine($"Server is running on {port}");
            Console.WriteLine("Server is waiting for the client to connect");

            //TcpClient client = server.AcceptTcpClient();


            while (true)
            {
                TcpClient client = server.AcceptTcpClient();
                Console.WriteLine("Client connected");

                NetworkStream stream = client.GetStream();

                lock (lockObj)
                {
                    byte[] buffer = new byte[1024];
                    int rb = stream.Read(buffer, 0, buffer.Length);
                    string userName = Encoding.UTF8.GetString(buffer, 0, rb);

                    if (!clients.Keys.Contains(userName))
                    {
                        clients.Add(userName, client);
                        //SaveingUserInFile();
                    }
                    //sendingList();
                    SendClientListToAll();
                }

                Thread clientThread = new Thread(HandleClient);
                clientThread.Start(client);
            }

        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }

    }

    //static void SaveingUserInFile()
    //{
    //    File.WriteAllLines("users.txt", clients.Keys);


    //}



    //static void LoadUsers()
    //{
    //    if (File.Exists(patth))
    //    {
    //        foreach (var line in File.ReadAllLines("users.txt"))
    //        {
    //            knownUsers.Add(line);
    //        }
    //    }
    //}
























    static void SendClientListToAll()
    {
        string clientList;

        lock (lockObj)
        {
            clientList = string.Join(",", clients.Keys);
        }

        byte[] data = Encoding.UTF8.GetBytes("CLIENTS:" + clientList);

        lock (lockObj)
        {
            

            foreach (var client in clients.Values)
            {
                try
                {
                    NetworkStream stream = client.GetStream();
                    stream.Write(data, 0, data.Length);
                }
                catch
                {
                    
                }
            }

        }
    }
    static void HandleClient(object obj)
    {
        try
        {
            TcpClient Senderclient = (TcpClient)obj;
            NetworkStream stream = Senderclient.GetStream();

            byte[] buffer = new byte[1024];

            string senderName = clients.First(x => x.Value == Senderclient).Key;

            while (true)
            {
                int bytesRead = stream.Read(buffer, 0, buffer.Length);
                if (bytesRead == 0) break;

                string data = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                //TO:user|MSG:hello
                if (data.StartsWith("TO:"))
                {
                    string[] parts = data.Split('|');
                    string targetUser = parts[0].Replace("TO:", "");
                    string message = parts[1].Replace("MSG:", "");

                    SendPrivateMessage(senderName, targetUser, message);
                }

            }
            Senderclient.Close();
            Console.WriteLine("Client disconnected");
        }
        catch (Exception ex) { Console.WriteLine(ex.Message); }
    }

    static void SendPrivateMessage(string fromUser, string toUser, string message)
    {
        if (!clients.ContainsKey(toUser))
            return;

        TcpClient targetClient = clients[toUser];
        NetworkStream stream = targetClient.GetStream();

        string payload = $"{fromUser}: {message}";
        byte[] data = Encoding.UTF8.GetBytes(payload);
        stream.Write(data, 0, data.Length);
    }


}