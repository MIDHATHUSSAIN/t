﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace ChatClint2.MVVM.Command
{
    class RelayCommand : ICommand
    {
        public event EventHandler? CanExecuteChanged;

        private readonly Action _execute;

        private readonly Func<bool> _canExecute;
        public RelayCommand(Action execute, Func<bool> mCanRun)
        {
            _execute = execute;

            _canExecute = mCanRun;
        }
        public bool CanExecute(object? parameter)
        {

            return _canExecute == null || _canExecute();
        }

        public void Execute(object? parameter)
        {
            _execute();
        }
        public void RaiseCanExecuteChanged()
        {
            CanExecuteChanged?.Invoke(this, EventArgs.Empty);
        }
    }
}
