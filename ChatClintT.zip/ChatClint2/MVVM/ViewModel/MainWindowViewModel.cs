﻿using ChatClint2.MVVM.Command;
using ChatClint2.Net;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;


using System.Windows.Input;

namespace ChatClint2.MVVM.ViewModel
{
    class MainWindowViewModel : INotifyPropertyChanged
    {
        string UL;
        bool isuserConnected = true;
        bool isError = true;
        public ICommand ConnectBtn { get; }
        private string _userName;

        private string message = "Message";
        private string chatLog;


        public AppSetting Settings
        {
            get { return AppSetting.Instance(); }
        }

        public string Message
        {
            get => message;
            set
            {
                message = value;
                OnPropertyChanged(nameof(Message));
            }
        }

        public string ChatLog
        {
            get => chatLog;
            set
            {
                chatLog = value;
                OnPropertyChanged(nameof(ChatLog));
            }
        }

        public ICommand SendCommand { get; }
        public string UserName
        {
            get { return _userName; }
            set
            {
                _userName = value;
                OnPropertyChanged();
                ;
                (ConnectBtn as RelayCommand)?.RaiseCanExecuteChanged();
            }
        }

        private Server _server;

        public event PropertyChangedEventHandler? PropertyChanged;

        public MainWindowViewModel()
        {
            _server = new Server();

            ConnectBtn = new RelayCommand(() => UserList(), () => !string.IsNullOrEmpty(UserName));
            SendCommand = new RelayCommand(() => SendMessage(), () => !string.IsNullOrEmpty(message));
            //ConnectBtn = new RelayCommand(() => _server.ConnectToServer(UserName), () => !string.IsNullOrEmpty(UserName));

        }
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


        private void abc()
        {
            Task.Run(() =>
            {
                while (true)
                {
                    try
                    {
                        _server.ConnectToServer(UserName);
                        break;
                    }
                    catch
                    {
                        Thread.Sleep(3000);
                    }
                }

            });

        }

        private void UserList()
        {
            if (isuserConnected)
            {
                UL = _server.ConnectToServer(UserName);
                StartListening();
                Console.Write(UL);
                string data = UL.Replace("CLIENTS:", "");

                Settings.MYUL = new ObservableCollection<string>(data.Split(',').Select(u => u.Trim()));


                if (UL != "Server is not connected")
                {
                    isuserConnected = false;

                }

            }

        }

        private void StartListening()
        {
            Task.Run(() =>
            {
                byte[] buffer = new byte[1024];
                while (true)
                {
                    try
                    {
                        int bytesRead = _server.Stream.Read(buffer, 0, buffer.Length);
                        if (bytesRead == 0)
                            break;

                        string data = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                        Application.Current.Dispatcher.Invoke(() =>
                        {
                            if (data.StartsWith("CLIENTS:"))
                            {
                                string users = data.Replace("CLIENTS:", "");
                                Settings.MYUL = new ObservableCollection<string>(
                                    users.Split(',').Select(u => u.Trim())
                                );
                            }
                            else
                            {
                                ChatLog += $"Server: {data}\n";
                            }
                        });
                    }
                    catch
                    {
                        break;
                    }
                }
            });
        }


        private string _selectedUser;
        public string SelectedUser
        {
            get => _selectedUser;
            set
            {
                _selectedUser = value;
                OnPropertyChanged();

                isError = _server.SendMessage(Message, _selectedUser);
                checkingforerror(isError);

                //_server.WantToConnect(_selectedUser);
            }
        }

        private void SendMessage()
        {

            //string reply = _server.SendMessage(Message, _selectedUser);

            isError = _server.SendMessage(Message, _selectedUser);
            checkingforerror(isError);
            if (isError)
            {
                ChatLog += $"You: {Message}\n";
            }

            //ChatLog += $"Server: {reply}\n";

            Message = "";
        }

        private void checkingforerror(bool isError)
        {
            if (!isError)
            {
                MessageBox.Show("server is turend off");
            }


        }
    }
}
